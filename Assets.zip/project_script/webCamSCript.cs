﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class webCamSCript : MonoBehaviour {
    public GameObject webCameraPlane;
    //public Text textComp;
    private Text textComp;

    public GameObject myStartpImage;

    public GameObject myCloseImage;

    private bool blnTOUCHSTARTEDobj;
    // Use this for initialirzation
    private Vector3 vctSTARTPOINTobj;
    private Vector3 vctCLOSEPOINTobj;
    private float dragStartDistance;

    private GameObject beam1;
    private GameObject beam2;

    private Button myButton;
    private string str_MESAGE_obj = "";
    private GameObject objParent;

    private float dragTotalDistance;
    //    private float flt_FREEZEX_obj;
    //    private float flt_FREEZEY_obj;
    //    private float flt_FREEZEZ_obj;
    // Use this for initialization
    void Start () {
        objParent = GameObject.Find("CubeWorld");
        //        if (Application.isMobilePlatform) {
        //            GameObject cameraParent = new GameObject("camParent");
        //            cameraParent.transform.position = this.transform.position;
        //            this.transform.position = cameraParent.transform.position;
        //            cameraParent.transform.Rotate(Vector3.right,90);
        //        }
        textComp = GameObject.Find("txtDistance").GetComponent<Text>() as Text;
        Input.gyro.enabled = true;

        WebCamTexture webcameraTexture = new WebCamTexture();
        webCameraPlane.GetComponent<MeshRenderer>().material.mainTexture = webcameraTexture;
        webcameraTexture.Play();


        //textComp.text = "Not yet Started";
    InitControls();
    }
    public void InitControls()
    {
        textComp.fontSize = 60;
        str_MESAGE_obj = "Not yet Started";
        if (beam1)
        {
            Destroy(beam1);
        }
        if (beam2)
        {
            Destroy(beam2);
        }
        vctSTARTPOINTobj = new Vector3();
        vctCLOSEPOINTobj = new Vector3();
  //      flt_FREEZEX_obj = 0f;
//        flt_FREEZEY_obj = 0f;
//        flt_FREEZEZ_obj = 0f;
        myButton.enabled = false;
    blnTOUCHSTARTEDobj = false;
    }
    // Update is called once per frame
    void Update () {
        if (Application.platform == RuntimePlatform.Android)
        {
            if (Input.GetKeyUp(KeyCode.Escape))
            {
                //quit application on return button
                Application.Quit();
                return;
            }
        }
                Quaternion cameraRotaion = new Quaternion(Input.gyro.attitude.x, Input.gyro.attitude.y, -Input.gyro.attitude.z, -Input.gyro.attitude.w);
                this.transform.rotation = cameraRotaion;
        if (Input.touchCount > 0)
        {
            //textComp.text = "Touch Identified";
            Touch touch = Input.GetTouch(Input.touches.Length - 1);
            if (touch.phase == TouchPhase.Ended)
            {
                Vector3 fingerPos = touch.position;
                RaycastHit hit;
                Ray ray = Camera.main.ScreenPointToRay(fingerPos);
                if (Physics.Raycast(ray, out hit, 100))
                {
                    //                textComp.text = "You just hit something, Hurray!";
                    if (blnTOUCHSTARTEDobj == false)
                    {
                        vctSTARTPOINTobj = hit.point;
                        beam1 = Instantiate(myStartpImage, vctSTARTPOINTobj, Quaternion.identity) as GameObject;
                        beam1.transform.parent = objParent.transform;
                        //                    flt_FREEZEX_obj = Camera.main.transform.position.x;
                        //                    flt_FREEZEY_obj = Camera.main.transform.position.y;
                        //                    flt_FREEZEZ_obj = Camera.main.transform.position.z;
                        //beam1.transform.parent = markerParent.transform;
                        str_MESAGE_obj = "Started Measurement";
                        blnTOUCHSTARTEDobj = true;
                    }
                    else if (blnTOUCHSTARTEDobj == true)
                    {
                        vctCLOSEPOINTobj = hit.point;
                        beam2 = Instantiate(myCloseImage, vctCLOSEPOINTobj, Quaternion.identity) as GameObject;
                        beam2.transform.parent = objParent.transform;
                        dragTotalDistance = (vctCLOSEPOINTobj - vctSTARTPOINTobj).magnitude;
                        str_MESAGE_obj = "Distance Calculated:" + dragTotalDistance + " cm ";
                    }
                }
                else
                {
                    str_MESAGE_obj = "Physics raycast not Identified";
                }
            }
        }
//        else
//        {
//            str_MESAGE_obj = "Touch not Identified";
//        }
//        if (flt_FREEZEX_obj>0f) {
//            Camera.main.transform.position = new Vector3(flt_FREEZEX_obj, flt_FREEZEY_obj, flt_FREEZEZ_obj);
//        }
        textComp.text = str_MESAGE_obj;// "Touch not Identified";
    }
}
